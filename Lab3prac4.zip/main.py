from domains.student import students, calculate_gpa
from domains. course import courses
from input import inputstudents, inputcourses, inputmarks
from output import liststudents, listcourses, showstudentmarks

marks = {}

def main():
    inputcourses()
    inputstudents()
    while True:
        print(" STUDENT MANAGEMENT SYSTEM ")
        print("1.List courses")
        print("2.List students")
        print("3.Input Marks for a Courses")
        print("4.Show Student Marks for a Courses")
        print("5.Exit")

        choose = input("Select an option (1-5):")

        if choose == '1':
            listcourses()
        elif choose == '2':
            liststudents()
        elif choose == '3':
            inputmarks()
        elif choose == '4':
            showstudentmarks()
        elif choose == '5':
            print("Exiting")
            break
        else:
            print("Can not choose")


if __name__ == "__main__":
    main()
