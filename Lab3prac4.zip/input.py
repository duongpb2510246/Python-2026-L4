import math
from domains.student import Student
from domains.course import Course


students = []
courses = []
marks = {}

def inputstudents():
    n = int(input("Numbers of students:"))
    for i in range (n):
        print(f"\n Student {i + 1}:")
        stid = input("Student ID:")
        stuname = input("Student name:")
        dob = input("Date of birth:")

        stu = {"id": stid, "name": stuname, "dob": dob}
        students.append(stu)

def inputcourses():
    n = int(input("\n Numbers of courses:"))
    for i in range(n):
        print(f"\nCourses {i + 1}:")
        coid = input("Courses ID:")
        coname = input("Courses name:")
        credits = float(input("Numbers of credits:"))
        cors = {"id": coid, "name": coname, "credits":credits}
        courses.append(cors)

def inputmarks():
    coid = input("Input courses ID:")
    marks[coid] = {}
    for stu in students:
        raw_mark = float(input(f"Input marks for students{stu['name']} (ID: {stu['id']}) "))
        floor_mark = math.floor(raw_mark*10)/10.0
        marks[coid][stu["id"]] = floor_mark