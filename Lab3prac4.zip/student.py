import numpy as np
class Student:
    def __init__(self, student_id, name, dob):
        self.id = student_id
        self.name = name
        self.dob = dob
        self.gpa = 0.0

    def calculate_gpa(self, courses, marks):
        stu_marks = []
        stu_credits = []
        for cors in courses:
            if cors.id in  marks and self.id in marks[cors.id]:
                stu_marks.append(marks[cors.id][self.id])
                stu_credits.append(cors.credits)
        if not stu_credits:
            self.gpa = 0.0
            return
        np_marks = np.array(stu_marks)
        np_credits = np.array(stu_credits)
        gpa = np.sum(np_marks * np_credits)/ np.sum(np_credits)
        return round(gpa, 2)