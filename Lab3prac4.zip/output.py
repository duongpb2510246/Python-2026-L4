def regpa(s):
    return s.get("gpa", 0.0)
  
def liststudents(students, courses, marks, calculate_gpa):
    if not students:
        print ("No students available")
        return
    for stu in students:
        stu["gpa"] = calculate_gpa(stu["id"])
    sorted_students = sorted(students, key = regpa, reverse = True)
    for stu in sorted_students:
        print(f"ID:{stu['id']} | Name: {stu['name']} | DoB: {stu['dob']} | GPA: {stu['gpa']}")
def listcourses(courses):
    if not courses:
        print("No courses available")
        return
    for cors in courses:
        print(f"ID: {cors['id']} | Name: {cors['name']} | Credits: {cors['credits']}")

def showstudentmarks(marks, students):
    coid = input("Input course ID to show marks:")

    if coid not in marks:
        print("No marks for course {coid}:")
        return

    print(f"\n Marks for course {coid}:")
    course_marks = marks[coid]

    for stu in students:
        stuid = stu["id"]
        if stuid in marks[coid]:
            print(f"ID: {stuid} | Name: {stu['name']} | Mark: {marks[coid][stuid]}")